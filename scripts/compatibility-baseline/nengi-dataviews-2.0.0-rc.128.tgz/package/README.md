# nengi-dataviews

`DataView` and `ArrayBuffer` binary backend for nengi. It is the normal binary
implementation for browsers and browser-shaped in-memory tests.

This backend is independently versioned. Its `peerDependencies.nengi` declares
compatible core releases. The rc.128 contract baseline installs as:

```sh
npm install nengi@2.0.0-rc.128 nengi-dataviews@2.0.0-rc.128
```

The official browser WebSocket adapter selects `dataViewBinary` by default.
Pass it explicitly for an in-memory transport or a custom adapter:

```ts
import { LocalClientAdapter } from 'nengi'
import { dataViewBinary } from 'nengi-dataviews'

const client = new Client(context, LocalClientAdapter, 20, {
    binary: dataViewBinary
})
```

Import only from the package root. See the
[nengi manual](https://github.com/timetocode/nengi/tree/rc/2.0.0/docs/ai) for
adapter selection and versioning guidance.
