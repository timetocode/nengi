# nengi-buffers

Node.js `Buffer` binary backend for nengi. It provides the `BinaryAdapter`,
reader, and writer used by the Node client and server adapters.

This backend is independently versioned. Its `peerDependencies.nengi` declares
compatible core releases. The rc.128 contract baseline installs as:

```sh
npm install nengi@2.0.0-rc.128 nengi-buffers@2.0.0-rc.128
```

The official Node adapters select `bufferBinary` by default. Pass it explicitly
when configuring an in-memory transport or a custom adapter:

```ts
import { LocalInstanceAdapter } from 'nengi'
import { bufferBinary } from 'nengi-buffers'

const adapter = new LocalInstanceAdapter(instance.adapterHost, {
    binary: bufferBinary
})
```

Import only from the package root. See the
[nengi manual](https://github.com/timetocode/nengi/tree/rc/2.0.0/docs/ai) for
adapter selection and versioning guidance.
