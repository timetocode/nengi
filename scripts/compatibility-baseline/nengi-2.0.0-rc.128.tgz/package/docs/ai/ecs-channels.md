# ECS channels

Nengi ECS channels assume a specific network ECS shape. Do not assume they match every ECS library or every use of the word ECS.

## The model

In a plain `Channel`, an entity is a replicated object with state. Nengi can scan the object and diff schema properties.

In `EcsChannel`, a root entity is only a network id. The state lives on component entities.

Root:

- Has an `nid`.
- Groups components.
- Has no schema properties for nengi to scan.

Component:

- Has its own `nid`.
- Has an `ntype`.
- Has schema properties.
- Has `pid`, the parent/root id.

Define each replicated ECS component type beside its nengi schema, component
type descriptor, and create function. See [shared-state.md](./shared-state.md)
for the recommended file shape. Do not give the root entity a schema; networked
state lives on components. Do not put component writers in shared component
files because writers are bound to a specific server channel instance.

Use plain objects for canonical ECS components. They make the network schema,
serialized fields, and explicit writer calls obvious:

```ts
const Transform = ecs.defineComponent<TransformComponent>(NType.Transform, 'Transform')

const transform = Transform.create({
    pid,
    nid: 0,
    x: 0,
    y: 0
})
```

Class instances are allowed when they expose the ECS fields directly and
serialize like plain objects:

```ts
class TransformComponent {
    readonly ntype = NType.Transform
    nid?: number

    constructor(
        public pid: number,
        public x: number,
        public y: number
    ) {}
}

const transform = world.add(new TransformComponent(pid, 0, 0))
```

Keep class behavior shallow. Hidden component methods that mutate networked
state can obscure the required channel writer call. Use `nid: 0` only when
passing a new component through an ECS channel that will assign its network id;
leave `nid` undefined for local components added directly to an `EcsWorld`.

## Basic ECS channel

```ts
const channel = new EcsChannel(instance.localState)
const Transform = channel.createComponentWriter(NType.Transform, context.getSchema(NType.Transform)!)

channel.subscribe(user)

const pid = channel.createEntity()
const transform = channel.addComponent(pid, {
    nid: 0,
    ntype: NType.Transform,
    x: 0,
    y: 0
})

transform.x = nextX
transform.y = nextY
Transform.groups.position(transform, nextX, nextY)
```

## Spatial ECS

Spatial ECS channels place roots in the grid using a selected spatial component. The root itself does not have position.

A root without a selected spatial component is absent from spatial replication.
Selecting an existing component with `setSpatialComponent(pid, component)` makes
the root and its components eligible for the next snapshot's cell visibility.
Removing the selected component removes the root from the spatial grid; select
another component to make it spatial again. With `bindEcsChannel`, use the bound
component's removal API so the game world and network channel stay aligned.

```ts
const channel = new EcsChannel2D(instance.localState, 100)
const Transform = channel.createComponentWriter(NType.Transform, context.getSchema(NType.Transform)!)

channel.subscribe(user, { x: 0, y: 0, halfWidth: 500, halfHeight: 500 })

const pid = channel.createEntity()
const transform = channel.addSpatialComponent(pid, {
    nid: 0,
    ntype: NType.Transform,
    x: 0,
    y: 0
})

transform.x = nextX
transform.y = nextY
Transform.groups.position(transform, nextX, nextY)
```

Use `EcsChannel3D` when vertical culling matters.

## Canonical small server

This is the intended minimal shape for a server-authoritative 2D ECS world.
The server owns gameplay state in an `EcsWorld`, binds selected roots to an
`EcsChannel2D`, and uses bound mutators at explicit mutation points.

Assume `NType`, schemas, and factory functions such as `createPlayer`,
`createTransform`, and `createContext` are defined by the game. Configure the
[transport adapter](./adapters.md) and
[connection handler](./networking-primitives.md#connection-handshake) before
starting the loop; an `Instance` without an `onConnect` handler denies connections.

```ts
import {
    CommandRouter,
    EcsChannel2D,
    EcsWorld,
    Instance,
    NetworkEvent,
    UserConnectionState,
    bindEcsChannel,
    ecs
} from 'nengi'
import type { User } from 'nengi'

const context = createContext()
const instance = new Instance(context)
const world = new EcsWorld()
const worldChannel = new EcsChannel2D(instance.localState, 100, { name: 'world' })
const replicated = bindEcsChannel(world, worldChannel, { context })

const Player = ecs.defineComponent<PlayerComponent>(NType.Player, 'Player')
const Transform = ecs.defineComponent<TransformComponent>(NType.Transform, 'Transform')
const PlayerNet = replicated.component(Player)
const TransformNet = replicated.component(Transform)

const playerPidByUser = new Map<number, number>()
const commands = new CommandRouter()

function viewFor(transform: TransformComponent) {
    return { x: transform.x, y: transform.y, halfWidth: 800, halfHeight: 600 }
}

function spawnPlayer(user: User) {
    const pid = replicated.createEntity()
    const transform = TransformNet.addSpatial(pid, {
        x: 100,
        y: 100,
        z: 0,
        rotation: 0,
        radius: 10
    })
    PlayerNet.add(pid, createPlayerState())

    playerPidByUser.set(user.id, pid)
    worldChannel.subscribe(user, viewFor(transform))
}

function removePlayer(user: User) {
    const pid = playerPidByUser.get(user.id)
    if (pid === undefined) {
        return
    }

    playerPidByUser.delete(user.id)

    replicated.removeEntity(pid)
}

commands.on<MoveCommand>(NType.MoveCommand, ({ user, command }) => {
    const pid = playerPidByUser.get(user.id)
    if (pid === undefined) {
        return
    }

    const transform = world.require(pid, Transform)
    applyMoveStep(transform, command)
    TransformNet.writer.props.x(transform, transform.x)
    TransformNet.writer.props.y(transform, transform.y)
    worldChannel.updateView(user, viewFor(transform))
})

function tick() {
    while (!instance.queue.isEmpty()) {
        const event = instance.queue.next()
        if (event.type === NetworkEvent.UserConnected) {
            if (event.user.connectionState === UserConnectionState.Open) spawnPlayer(event.user)
        } else if (event.type === NetworkEvent.UserDisconnected) {
            removePlayer(event.user)
        } else {
            commands.process(event)
        }
    }

    instance.processRequests()
    instance.step()
}
```

The important boundaries:

- The root `pid` is the gameplay entity id.
- Networked state lives on components.
- The binding creates/removes network ids and keeps bound world roots aligned.
- `EcsWorld` is the game query surface.
- ECS resources aka singletons live in `EcsWorld` when systems need shared
  services or state that is not a component on one entity.
- Bound mutators assign state and emit manual component mutations together.
- Bound writers are append-only for code that manages assignment itself.
- Spatial ECS writers also refresh the root's spatial cell before snapshot output.
  Call `updateSpatialComponent` only for direct spatial changes that do not go
  through a component writer.

If the game has several ECS spaces, create several channels and give each
channel a header or name that the client can classify.

## Canonical small client

On the client, apply channel closes before classifying opens and applying ECS
channel frames to an `EcsWorld`. This releases old roots and local resources
before a replacement can reuse their ids. Keep presentation code outside the
network applier.

```ts
import { SERVER_TICK_RATE } from '../shared/network-config'
import {
    Client,
    EcsWorld,
    applyEcsChannelClose,
    applyEcsChannelFrame,
    ecs
} from 'nengi'
import type { Frame } from 'nengi'

const client = new Client(context, WebSocketClientAdapter, SERVER_TICK_RATE)
const world = new EcsWorld()
const channelByName = new Map<string, number>()
const networkRoots = new Set<number>()
let connected = false

const Player = ecs.defineComponent<PlayerComponent>(NType.Player, 'Player')
const Transform = ecs.defineComponent<TransformComponent>(NType.Transform, 'Transform')

function clearNetworkSession() {
    connected = false
    for (const pid of networkRoots) {
        destroyPresentation(pid)
        world.removeEntity(pid)
    }
    networkRoots.clear()
    channelByName.clear()
}

client.setDisconnectHandler(clearNetworkSession)
await client.connect('ws://localhost:8079')
connected = client.connectionState === 'connected'

function applyNetworkFrame(frame: Frame) {
    frame.closedChannels.forEach(channel => {
        if (channel.channelId === channelByName.get('world')) {
            applyEcsChannelClose(world, channel, {
                beforeRemoveEntity(pid) {
                    destroyPresentation(pid)
                    networkRoots.delete(pid)
                }
            })
            channelByName.delete('world')
        }
    })

    frame.openedChannels.forEach(channel => {
        if (channel.header.name === 'world') {
            channelByName.set('world', channel.channelId)
        }
    })

    frame.channels.forEach(channel => {
        if (channel.channelId !== channelByName.get('world')) {
            return
        }

        channel.messages.forEach(handleWorldMessage)

        const changes = applyEcsChannelFrame(world, channel, {
            beforeRemoveEntity(pid) {
                destroyPresentation(pid)
                networkRoots.delete(pid)
            }
        })
        changes.createdEntities.forEach(pid => networkRoots.add(pid))
        changes.deletedComponents.forEach(component => {
            if (component.ntype === NType.Player && component.pid !== undefined && world.hasEntity(component.pid)) {
                destroyPresentation(component.pid)
            }
        })
        changes.createdComponents.forEach(component => {
            if (component.ntype === NType.Player) {
                createPlayerPresentation(component.pid)
            }
        })
        changes.updatedComponents.forEach(update => {
            markPresentationDirty(update.component.pid, update.prop)
        })
    })
}

function frame() {
    if (!connected) {
        return
    }
    for (const frame of client.network.drainFrames()) {
        applyNetworkFrame(frame)
    }

    world.query(Player, Transform).all((pid, player, transform) => {
        renderPlayer(pid, player, transform)
    })

    client.flush()
    requestAnimationFrame(frame)
}

if (connected) requestAnimationFrame(frame)
```

`networkRoots` tracks roots applied to this client world, including roots with
no Player component. On transport disconnect, clean them up immediately; there
will be no final channel-close frame. `destroyPresentation` should tolerate a
root without presentation resources. Local entities outside this set survive.
The network loop starts only after acceptance and stops on disconnect. Follow
the [connection lifetime guidance](./client-state.md#connection-lifetime) when
rebuilding a session.

Component removal can leave its root alive. The handler releases Player
presentation for that case before creating any replacement presentation. Root
removal uses `beforeRemoveEntity`; the `world.hasEntity` check avoids repeating
that cleanup after the whole root was removed.

For multiple ECS channels, do not infer meaning from component type alone. Route
by channel identity first, then apply the frame or close event to the appropriate
local world or feature system.

When an ECS root is deleted, either by a normal channel frame or a channel close,
the applier removes the whole root entity from the `EcsWorld`, including
local-only components attached to that root. Use `beforeRemoveEntity` to destroy
renderer, physics, debug, or UI resources before the components are removed:

```ts
applyEcsChannelClose(world, channel, {
    beforeRemoveEntity(pid, components) {
        destroyPresentation(pid)
    }
})
```

If local state should outlive the replicated root, move or copy it onto a
separate local entity before applying the network delete/close.

The returned `changes.deletedEntities` are network root delete facts. The
returned `changes.removedEntities` are roots actually removed from the
`EcsWorld`, and `changes.removedLocalComponents` lists local components removed
because they were attached to those roots.

## When to use ECS channels

Use ECS channels when:

- The game already treats entities as ids and state as components.
- Systems have explicit mutation points.
- Components are individually meaningful network records.
- You want to send one changed component without scanning or sending a wide object.

Avoid ECS channels when:

- The game is object-oriented and each object already has a small schema.
- You only need parent/child visibility, not root/component network identity.
- Your ECS allows arbitrary recursive/cyclic graphs that do not match nengi's one root-to-components layer.

## ECS vs parent/child entities

Parent/child entities are a visibility cascade in the normal entity model. If a parent is visible, children become visible too.

ECS channels are a different network model: roots are ids, and components are the replicated records.

Do not confuse these two. Parent/child is useful for scenegraph-like or object-with-parts state. ECS channels are useful for root ids plus component state.

## Mutation responsibility

ECS channels are manual. If a component changes and game code does not call the component writer, nengi will not send the update.

For plain and spatial ECS channels, create the root before adding its components.
Arrange structural changes so that each newly created root or component survives
its first server snapshot; remove it in a subsequent tick. Decide whether a
temporary object is needed before allocating network identity. These lifetime
rules let the engine retain simpler bookkeeping and share snapshot work.

An existing component can be removed during a later tick even if it has already
been written that tick. Other live components' writes must still arrive correctly.
If game logic can decide removals before producing manual writes, do so to avoid
generating updates that will be discarded. Do not depend on same-tick creation
and cancellation as part of the fast-channel contract.

Plain `EcsChannel` discards already queued writes for removed components once
before producing subscriber snapshots. This also contains a cancelled create
that has no visible create/delete pair. It does not make a removed component's
raw writer handle valid again. Prefer bound mutators for lifecycle validation.

Do not call component writers with draft components that have not been added to
the channel. A component with `nid: 0` is not networked. After a successful
`removeEntity`, component nids may be returned to `0`; capture any ids you need
before removal.
