# Plain object channels

This is the canonical small non-ECS shape. Use it when game objects are ordinary
network entities with `nid`, `ntype`, and schema properties. The server owns
those objects directly, and the client reads nengi's raw `EntityStore` plus
per-frame channel facts.

For a 2D world where visibility depends on position, use `Channel2D`. For a
small arena where every subscribed user sees every object, use `Channel` with
the same client shape.

Define each replicated entity type beside its nengi schema and create function.
See [shared-state.md](./shared-state.md) for the recommended file shape. For
plain channels, the replicated object is the network entity: it has `nid`,
`ntype`, schema properties, and a registered nengi schema.

For a complete copy-and-run project, start with the [shared room starter](./getting-started.md).
The fragments below show how to adapt that flow to a spatial game.

## Canonical small server

Assume `NType`, schemas, and factory functions such as `createPlayer` and
`createContext` are defined by the game. Configure the [transport adapter](./adapters.md)
and [connection handler](./networking-primitives.md#connection-handshake) before
starting the loop; an `Instance` without an `onConnect` handler denies connections.

```ts
import {
    Channel2D,
    CommandRouter,
    Instance,
    NetworkEvent,
    UserConnectionState
} from 'nengi'
import type { User } from 'nengi'

const context = createContext()
const instance = new Instance(context)
const world = new Channel2D(instance.localState, 100, { name: 'world' })

const playerByUser = new Map<number, PlayerEntity>()
const commands = new CommandRouter()

function viewFor(player: PlayerEntity) {
    return { x: player.x, y: player.y, halfWidth: 800, halfHeight: 600 }
}

function spawnPlayer(user: User) {
    const player = createPlayer(100, 100)
    world.addEntity(player)
    world.subscribe(user, viewFor(player))
    playerByUser.set(user.id, player)

    user.queueMessage({
        ntype: NType.YouArePlayer,
        nid: player.nid
    })
}

function removePlayer(user: User) {
    const player = playerByUser.get(user.id)
    if (!player) {
        return
    }

    playerByUser.delete(user.id)
    world.removeEntity(player)
}

commands.on<MoveCommand>(NType.MoveCommand, ({ user, command }) => {
    const player = playerByUser.get(user.id)
    if (!player) {
        return
    }

    // Game helper: validates direction and duration, bounds total input time,
    // then applies the same movement step used by any local prediction.
    if (!validateAndApplyMove(player, command)) return

    // Automatic spatial channels still need to learn when an entity moves so
    // nengi can update cell membership and visibility.
    world.moveEntity(player)
    world.updateView(user, viewFor(player))
})

function tick() {
    while (!instance.queue.isEmpty()) {
        const event = instance.queue.next()
        if (event.type === NetworkEvent.UserConnected) {
            if (event.user.connectionState === UserConnectionState.Open) spawnPlayer(event.user)
        } else if (event.type === NetworkEvent.UserDisconnected) {
            removePlayer(event.user)
        } else {
            commands.process(event)
        }
    }

    instance.processRequests()
    instance.step()
}
```

The server object is the network object. Mutating `player.x` and `player.y`
changes authoritative state. Nengi's automatic channel diffing sends schema
property changes; `moveEntity` handles spatial membership.

If the game uses `ManualChannel2D` instead, keep the same object model but call
manual writers at every networked mutation point.

## Canonical small client

The non-ECS client uses `client.network.store` for current authoritative network
state. Use `Frame` for what changed in each snapshot, then derive the game's
presentation records from those facts and store lookups.

Within each frame, clean up closed channels before recording opens and applying
entity changes. A replacement can reuse the old channel or entity ids.

```ts
import { SERVER_TICK_RATE } from '../shared/network-config'
import {
    AdaptiveInterpolator,
    Client
} from 'nengi'
import type { Frame } from 'nengi'

const client = new Client(context, WebSocketClientAdapter, SERVER_TICK_RATE)
const interpolator = new AdaptiveInterpolator(client)
const channelByName = new Map<string, number>()
const sprites = new Map<number, Sprite>()

let controlledNid = 0
let connected = false

client.setDisconnectHandler(() => {
    connected = false
    sprites.forEach(sprite => sprite.destroy())
    sprites.clear()
    channelByName.clear()
    controlledNid = 0
})

await client.connect('ws://localhost:8079')
connected = client.connectionState === 'connected'

function applyNetworkFrame(frame: Frame) {
    frame.closedChannels.forEach(channel => {
        if (channel.channelId === channelByName.get('world')) {
            channel.entityNids.forEach(nid => {
                sprites.get(nid)?.destroy()
                sprites.delete(nid)
            })
            channelByName.delete('world')
        }
    })

    frame.openedChannels.forEach(channel => {
        if (channel.header.name === 'world') {
            channelByName.set('world', channel.channelId)
        }
    })

    frame.messages.forEach(message => {
        if (message.ntype === NType.YouArePlayer) {
            controlledNid = message.nid
        }
    })

    const worldId = channelByName.get('world')
    const worldFrame = worldId === undefined ? undefined : frame.getChannel(worldId)
    if (worldFrame) {
        worldFrame.messages.forEach(message => {
            if (message.ntype === NType.Impact) {
                spawnImpactEffect(message.x, message.y)
            }
        })

        worldFrame.createEntities.forEach(entity => {
            if (entity.ntype === NType.Player) {
                sprites.set(entity.nid, createPlayerSprite(entity as PlayerEntity))
            }
        })

        worldFrame.updateEntities.forEach(update => {
            const entity = client.network.store.get(update.nid)
            if (entity) {
                markSpriteDirty(entity.nid, update.prop)
            }
        })

        worldFrame.deletedEntities.forEach(deleted => {
            sprites.get(deleted.nid)?.destroy()
            sprites.delete(deleted.nid)
        })
    }
}

function render(excludeNid?: number) {
    const sample = interpolator.sampleEntities(sprites.keys(), 100)

    sample.entities.forEach(entity => {
        if (entity.nid === excludeNid) return
        const sprite = sprites.get(entity.nid)
        if (sprite) {
            sprite.x = entity.x
            sprite.y = entity.y
        }
    })
}

function frame() {
    if (!connected) {
        requestAnimationFrame(frame)
        return
    }
    for (const frame of client.network.drainFrames()) {
        applyNetworkFrame(frame)
    }

    render()
    sendMoveCommandsAtFixedRate()
    client.flush()
    requestAnimationFrame(frame)
}
```

This non-predicting loop interpolates every player. Pass an `excludeNid` only
when a complete local prediction path owns that player's rendering; the
[prediction snippet](./canonical-snippets.md#predicted-movement-loop) shows that change.
`sendMoveCommandsAtFixedRate` is application code: bound catch-up after stalls,
clear held input when hidden, and enforce input time on the server. The
[complete starter](./getting-started.md) instead sends a destination on each click.

The client meaning comes from channel identity first, then entity type. A
`Player` created in the world channel and a `Player` created in a separate
spectator, replay, or party channel may require different presentation.

Transport disconnect is a separate cleanup boundary: do not wait for a channel
close frame after the socket closes. Register the disconnect handler before
connecting, release application-owned presentation and input/prediction state,
and stop consuming frames or producing commands for that session. The snippet
above stops its network loop while disconnected. Follow the
[connection lifetime guidance](./client-state.md#connection-lifetime) when
rebuilding a session.

## Boundaries

- Use `Channel` or `Channel2D/3D` when objects are normal replicated records.
- Use the raw client `EntityStore` as authoritative state.
- Use `Frame` facts to create, mark dirty, and destroy presentation.
- Use messages for one-shot context such as "you control this nid."
- Use commands for repeated input.
- Keep the client presentation bridge small and domain-specific. Use
  `EntityStore` and `Frame` as the network-state boundary, and make any local
  presentation records a direct derivation of those facts.

If an entity moves between channels, model it as delete plus create. Do not
expect one stable `nid` to transfer between channels.
