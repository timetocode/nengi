# Spatial channels

Spatial channels model worlds where visibility is tied to position. They use
grid cells so nengi can process only the entities in or near a user's view.
Performance comes from skipping irrelevant space, but the API choice starts from
the game's visibility rule.

## 2D, 3D, and projected planes

Use `Channel2D` for 2D worlds and for 3D games where culling is horizontal.

For 3D games that ignore vertical culling, use the `xz` plane:

```ts
const channel = new Channel2D(instance.localState, 100, {
    plane: 'xz'
})

channel.subscribe(user, {
    x: player.x,
    z: player.z,
    halfX: 500,
    halfZ: 500
})
```

Use `Channel3D` when vertical visibility matters.

## Views

2D views can be rectangular or coarse circular:

```ts
channel.subscribe(user, { x: 0, y: 0, halfWidth: 500, halfHeight: 500 })
channel.updateView(user, { x: 200, y: 100, radius: 500 })
```

3D views can be box or coarse sphere:

```ts
channel.subscribe(user, { x: 0, y: 0, z: 0, halfWidth: 500, halfHeight: 500, halfDepth: 500 })
channel.updateView(user, { x: 0, y: 0, z: 0, radius: 500 })
```

Circle and sphere views are coarse cell queries. Nengi includes occupied cells touched by the circle/sphere; it does not test every entity against the exact shape.

## Moving entities

For automatic spatial channels, update the spatial index when an entity moves:

```ts
player.x = nextX
player.y = nextY
channel.moveEntity(player)
```

For manual spatial channels, writer calls refresh spatial membership before
snapshot output. Do not also call `moveEntity` after a normal manual position
writer.

## Cell size

Cell size is a game-specific tuning knob.

Smaller cells:

- More precise culling.
- More cell bookkeeping.
- More cell keys per large view.

Larger cells:

- Less bookkeeping.
- More extra entities included near view edges.
- Better for sparse worlds or large views.

Start with a cell size near the size of meaningful interest areas, then benchmark.

## Messages

Spatial channel messages are culled immediately. When you call `addMessage(message)`, the channel checks current subscribed user views and queues the message directly to matching users. On the client, read those messages from the matching `ChannelFrame`:

```ts
const worldFrame = frame.getChannel(worldChannelId)
worldFrame?.messages.forEach(handleWorldMessage)
```

Use `addInterpolatedMessage(message)` for spatial effects that should be culled
by the same view and delivered on the client interpolation timeline.

This differs from non-spatial channels, which store broadcast messages until the snapshot boundary.

## When spatial is the right model

Use spatial channels when:

- The world has many entities.
- Each user sees a small fraction of the world.
- Users are spread out or clustered into limited areas.
- Visibility is naturally position-based.

Spatial channels are usually the wrong model when:

- Everyone sees almost everything.
- Entity counts are small.
- Visibility is permission-based rather than position-based.
- Views are so large that most cells are included.

## Manual spatial

Use `ManualChannel2D/3D` when spatial culling is the right visibility
model and hot mutations are explicit. This is often the highest-performance path
for large worlds with low mutation fractions.

Manual spatial writers refresh cell membership before snapshot output. If a
position writer is called, do not also call the automatic-channel
`moveEntity` method for that same mutation.
